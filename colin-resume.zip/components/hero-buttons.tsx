"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Download, Sparkles, ExternalLink } from "lucide-react"
import { cn } from "@/lib/utils"

export function HeroButtons() {
  const [isHovering, setIsHovering] = useState("")

  return (
    <div className="flex flex-row gap-3 pt-4 justify-center">
      <Button
        asChild
        className={cn(
          "relative overflow-hidden transition-all duration-300",
          isHovering === "resume" && "translate-y-[-2px]",
        )}
        onMouseEnter={() => setIsHovering("resume")}
        onMouseLeave={() => setIsHovering("")}
      >
        <Link href="/colin-zhang-resume.pdf" download>
          <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-primary/10 animate-gradient" />
          <div className="relative z-10 flex items-center">
            <Download className="mr-2 h-4 w-4" />
            <span>View My Work</span>
            <Sparkles
              className={cn(
                "ml-2 h-3 w-3 text-primary-foreground transition-opacity duration-300",
                isHovering === "resume" ? "opacity-100" : "opacity-0",
              )}
            />
          </div>
        </Link>
      </Button>
      <Button
        variant="outline"
        asChild
        className={cn(
          "relative group transition-all duration-300",
          isHovering === "connect" && "translate-y-[-2px] border-primary",
        )}
        onMouseEnter={() => setIsHovering("connect")}
        onMouseLeave={() => setIsHovering("")}
      >
        <Link href="#contact">
          <div className="flex items-center">
            <span className="relative z-10">Let's Connect</span>
            <ExternalLink
              className={cn(
                "ml-2 h-4 w-4 transition-all duration-300",
                isHovering === "connect" ? "translate-x-1" : "",
              )}
            />
          </div>
        </Link>
      </Button>
    </div>
  )
}

