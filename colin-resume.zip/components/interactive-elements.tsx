"use client"

import { useEffect, useRef } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Sparkles } from "lucide-react"

export function InteractiveElements() {
  const particlesRef = useRef<HTMLDivElement>(null)
  const typingTextRef = useRef<HTMLSpanElement>(null)

  // Typing effect
  useEffect(() => {
    const phrases = [
      "Machine Learning Enthusiast",
      "Software Developer",
      "Entrepreneur",
      "UC Berkeley Student",
      "AI Researcher",
    ]

    let currentPhraseIndex = 0
    let currentCharIndex = 0
    let isDeleting = false
    let typingSpeed = 100

    function typeEffect() {
      const typingElement = typingTextRef.current
      if (!typingElement) return

      const currentPhrase = phrases[currentPhraseIndex]

      if (isDeleting) {
        typingElement.textContent = currentPhrase.substring(0, currentCharIndex - 1)
        currentCharIndex--
        typingSpeed = 50
      } else {
        typingElement.textContent = currentPhrase.substring(0, currentCharIndex + 1)
        currentCharIndex++
        typingSpeed = 100
      }

      if (!isDeleting && currentCharIndex === currentPhrase.length) {
        isDeleting = true
        typingSpeed = 1000 // Pause at the end
      } else if (isDeleting && currentCharIndex === 0) {
        isDeleting = false
        currentPhraseIndex = (currentPhraseIndex + 1) % phrases.length
        typingSpeed = 500 // Pause before typing next phrase
      }

      setTimeout(typeEffect, typingSpeed)
    }

    typeEffect()
  }, [])

  // Particle effect
  useEffect(() => {
    const particlesContainer = particlesRef.current
    if (!particlesContainer) return

    const canvas = document.createElement("canvas")
    canvas.width = particlesContainer.offsetWidth
    canvas.height = particlesContainer.offsetHeight
    particlesContainer.appendChild(canvas)

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const particles: Array<{
      x: number
      y: number
      radius: number
      color: string
      speedX: number
      speedY: number
    }> = []

    const particleCount = 50

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        radius: Math.random() * 3 + 1,
        color: `rgba(59, 130, 246, ${Math.random() * 0.5})`,
        speedX: Math.random() * 0.5 - 0.25,
        speedY: Math.random() * 0.5 - 0.25,
      })
    }

    function animate() {
      if (!ctx) return
      requestAnimationFrame(animate)
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      particles.forEach((particle) => {
        particle.x += particle.speedX
        particle.y += particle.speedY

        if (particle.x < 0 || particle.x > canvas.width) {
          particle.speedX = -particle.speedX
        }

        if (particle.y < 0 || particle.y > canvas.height) {
          particle.speedY = -particle.speedY
        }

        ctx.beginPath()
        ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2)
        ctx.fillStyle = particle.color
        ctx.fill()
      })

      // Draw connections
      particles.forEach((particle, i) => {
        particles.slice(i + 1).forEach((otherParticle) => {
          const dx = particle.x - otherParticle.x
          const dy = particle.y - otherParticle.y
          const distance = Math.sqrt(dx * dx + dy * dy)

          if (distance < 100) {
            ctx.beginPath()
            ctx.strokeStyle = `rgba(59, 130, 246, ${0.2 * (1 - distance / 100)})`
            ctx.lineWidth = 0.5
            ctx.moveTo(particle.x, particle.y)
            ctx.lineTo(otherParticle.x, otherParticle.y)
            ctx.stroke()
          }
        })
      })
    }

    animate()

    const handleResize = () => {
      canvas.width = particlesContainer.offsetWidth
      canvas.height = particlesContainer.offsetHeight
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
      particlesContainer.removeChild(canvas)
    }
  }, [])

  return (
    <section className="py-8 relative overflow-hidden">
      <div className="absolute inset-0 -z-10" ref={particlesRef}></div>
      <Card className="border-primary/20 bg-gradient-to-r from-primary/5 to-primary/10">
        <CardContent className="p-8">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="flex-1">
              <h3 className="text-2xl font-bold mb-4 flex items-center">
                <Sparkles className="h-5 w-5 mr-2 text-primary" /> Fun Facts About Me
              </h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <span className="bg-primary/20 text-primary rounded-full w-6 h-6 flex items-center justify-center mr-2 mt-0.5">
                    1
                  </span>
                  <span>I've built a business with over 30,000 customers while studying Computer Science</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-primary/20 text-primary rounded-full w-6 h-6 flex items-center justify-center mr-2 mt-0.5">
                    2
                  </span>
                  <span>My machine learning research is helping to forecast diseases like Alzheimer's</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-primary/20 text-primary rounded-full w-6 h-6 flex items-center justify-center mr-2 mt-0.5">
                    3
                  </span>
                  <span>I've worked with cutting-edge AI models like OpenAI's o1 and 4o</span>
                </li>
              </ul>
            </div>
            <div className="flex-1">
              <div className="relative h-64 w-full rounded-lg overflow-hidden border border-primary/20">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center">
                  <div className="text-center">
                    <h4 className="text-xl font-bold mb-2">My Tech Journey</h4>
                    <div className="typing-effect h-12 flex items-center justify-center text-primary">
                      <span ref={typingTextRef} className="inline-block"></span>
                      <span className="cursor inline-block w-0.5 h-6 bg-primary ml-0.5 animate-pulse"></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </section>
  )
}

