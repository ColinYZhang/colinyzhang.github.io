"use client"

import type React from "react"

import { useEffect, useState, useCallback } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Github, Linkedin } from "lucide-react"
import { cn } from "@/lib/utils"

export function NavHeader() {
  const [activeSection, setActiveSection] = useState("about")

  // Debounced section update
  const updateActiveSection = useCallback((sectionId: string) => {
    setActiveSection(sectionId)
    const url = new URL(window.location.href)
    url.hash = `#${sectionId}`
    window.history.replaceState({}, "", url)
  }, [])

  useEffect(() => {
    let timeout: NodeJS.Timeout

    const observer = new IntersectionObserver(
      (entries) => {
        // Clear any pending timeout
        if (timeout) {
          clearTimeout(timeout)
        }

        // Filter for the most visible section
        const visibleSections = entries.filter((entry) => entry.isIntersecting)
        if (visibleSections.length > 0) {
          // Sort by visibility ratio and get the most visible
          const mostVisible = visibleSections.reduce((prev, current) => {
            return prev.intersectionRatio > current.intersectionRatio ? prev : current
          })

          // Debounce the update
          timeout = setTimeout(() => {
            updateActiveSection(mostVisible.target.id)
          }, 100) // Small delay to prevent flickering
        }
      },
      {
        rootMargin: "-10% 0px -80% 0px", // Adjusted margins for better section detection
        threshold: [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1], // More granular thresholds
      },
    )

    const sections = document.querySelectorAll("section[id]")
    sections.forEach((section) => observer.observe(section))

    return () => {
      if (timeout) {
        clearTimeout(timeout)
      }
      sections.forEach((section) => observer.unobserve(section))
    }
  }, [updateActiveSection])

  const navItems = [
    { href: "#about", label: "About" },
    { href: "#education", label: "Education" },
    { href: "#skills", label: "Skills" },
    { href: "#experience", label: "Experience" },
    { href: "#contact", label: "Contact" },
  ]

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault()
    const sectionId = href.slice(1)
    const element = document.querySelector(href)

    // Immediately update active section on click
    updateActiveSection(sectionId)

    if (element) {
      const offsetTop = element.getBoundingClientRect().top + window.pageYOffset
      window.scrollTo({
        top: offsetTop - 64,
        behavior: "smooth",
      })
    }
  }

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur">
      <div className="container flex h-16 items-center justify-between">
        <div className="font-bold text-xl">
          <span className="text-primary">{"<"}</span>
          Colin Zhang
          <span className="text-primary">{"/>"}</span>
        </div>
        <nav className="hidden md:flex gap-6">
          {navItems.map(({ href, label }) => (
            <Link
              key={href}
              href={href}
              onClick={(e) => handleClick(e, href)}
              className={cn(
                "text-muted-foreground hover:text-foreground transition-colors relative py-1",
                activeSection === href.slice(1) && "text-primary font-medium",
              )}
            >
              {label}
              {activeSection === href.slice(1) && (
                <span className="absolute bottom-0 left-0 w-full h-0.5 bg-primary rounded-full transition-all duration-300" />
              )}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" asChild>
            <Link href="https://github.com/ColinYZhang" target="_blank" rel="noopener noreferrer">
              <Github className="h-4 w-4" />
              <span className="sr-only">GitHub</span>
            </Link>
          </Button>
          <Button variant="outline" size="icon" asChild>
            <Link href="https://www.linkedin.com/in/colin-zhang-b3988924a/" target="_blank" rel="noopener noreferrer">
              <Linkedin className="h-4 w-4" />
              <span className="sr-only">LinkedIn</span>
            </Link>
          </Button>
          <Button variant="default" asChild>
            <Link href="#contact" onClick={(e) => handleClick(e, "#contact")}>
              Contact Me
            </Link>
          </Button>
        </div>
      </div>
    </header>
  )
}

