import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Github, Linkedin, Mail, MapPin, Briefcase, GraduationCap, Code, Building } from "lucide-react"
import { InteractiveElements } from "@/components/interactive-elements"
import { NavHeader } from "@/components/nav-header"
import { SectionWrapper } from "@/components/section-wrapper"
import { HeroButtons } from "@/components/hero-buttons"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      <NavHeader />

      <main className="container py-10">
        {/* Hero Section */}
        <SectionWrapper id="about" className="py-12 md:py-24 lg:py-32">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl mb-4">
              <span className="text-primary">{"<"}</span>
              Colin Zhang
              <span className="text-primary">{"/>"}</span>
            </h1>
            <h2 className="text-xl text-muted-foreground mb-4">Computer Science Student at UC Berkeley</h2>
            <p className="text-muted-foreground max-w-[600px] mx-auto mb-6">
              Passionate about machine learning, software development, and entrepreneurship with experience in AI
              research and business leadership.
            </p>
            <HeroButtons />
          </div>
        </SectionWrapper>

        {/* Fun Interactive Element */}
        <SectionWrapper>
          <InteractiveElements />
        </SectionWrapper>

        {/* Contact Info Bar */}
        <SectionWrapper className="grid grid-cols-1 md:grid-cols-2 gap-4 py-6 border-y">
          <div className="flex items-center gap-3">
            <MapPin className="h-5 w-5 text-muted-foreground" />
            <div>
              <p className="text-sm text-muted-foreground">Location</p>
              <p>Glen Allen, Virginia</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Mail className="h-5 w-5 text-muted-foreground" />
            <div>
              <p className="text-sm text-muted-foreground">Email</p>
              <p>colinzhang@berkeley.edu</p>
            </div>
          </div>
        </SectionWrapper>

        {/* Education Section */}
        <SectionWrapper id="education" className="py-12">
          <div className="space-y-2 mb-8">
            <h2 className="text-3xl font-bold tracking-tight flex items-center gap-2">
              <GraduationCap className="h-6 w-6" /> Education
            </h2>
            <p className="text-muted-foreground">My academic background and coursework</p>
          </div>

          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row justify-between mb-4">
                <div>
                  <h3 className="text-xl font-bold">University of California, Berkeley</h3>
                  <p className="text-muted-foreground">Bachelor of Science in Computer Science</p>
                </div>
                <div className="text-right mt-2 md:mt-0">
                  <Badge variant="outline" className="text-sm">
                    Expected May 2027
                  </Badge>
                </div>
              </div>

              <div className="mt-4">
                <h4 className="font-semibold mb-2">Relevant Coursework:</h4>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">CS 61A</Badge>
                  <Badge variant="secondary">CS 61B</Badge>
                  <Badge variant="secondary">Math 56 (Linear Algebra)</Badge>
                  <Badge variant="secondary">Data C8 (Data Science)</Badge>
                  <Badge variant="secondary">Discrete Math</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </SectionWrapper>

        {/* Skills Section */}
        <SectionWrapper id="skills" className="py-12">
          <div className="space-y-2 mb-8">
            <h2 className="text-3xl font-bold tracking-tight flex items-center gap-2">
              <Code className="h-6 w-6" /> Skills
            </h2>
            <p className="text-muted-foreground">My technical skills and competencies</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-4">Programming Languages</h3>
                <div className="flex flex-wrap gap-2">
                  <Badge>Python</Badge>
                  <Badge>Java</Badge>
                  <Badge>SQL</Badge>
                  <Badge>Scheme</Badge>
                  <Badge variant="outline">C/C++</Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-4">Tools & Technologies</h3>
                <div className="flex flex-wrap gap-2">
                  <Badge>Git</Badge>
                  <Badge>Visual Studio</Badge>
                  <Badge>IntelliJ</Badge>
                  <Badge>PyCharm</Badge>
                  <Badge>Google Collab</Badge>
                  <Badge>Unity</Badge>
                  <Badge>Excel</Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-4">Libraries & Frameworks</h3>
                <div className="flex flex-wrap gap-2">
                  <Badge>Pandas</Badge>
                  <Badge>NumPy</Badge>
                  <Badge>TensorFlow</Badge>
                  <Badge>ScitKit-Learn</Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-4">Languages</h3>
                <div className="flex flex-wrap gap-2">
                  <Badge>English (Fluent)</Badge>
                  <Badge>Chinese (Proficient)</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </SectionWrapper>

        {/* Experience Section */}
        <SectionWrapper id="experience" className="py-12">
          <div className="space-y-2 mb-8">
            <h2 className="text-3xl font-bold tracking-tight flex items-center gap-2">
              <Briefcase className="h-6 w-6" /> Experience
            </h2>
            <p className="text-muted-foreground">My professional experience and projects</p>
          </div>

          <Tabs defaultValue="ml" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="ml">Machine Learning</TabsTrigger>
              <TabsTrigger value="business">Business & Engineering</TabsTrigger>
            </TabsList>

            <TabsContent value="ml" className="space-y-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold">FRONT-IA</h3>
                      <p className="text-muted-foreground">AI & IA Software Developer [Group Leader]</p>
                    </div>
                    <div className="text-right mt-2 md:mt-0">
                      <Badge variant="outline">December 2024 – May 2025</Badge>
                    </div>
                  </div>

                  <ul className="list-disc pl-5 space-y-2 mt-4">
                    <li>
                      Created application that integrates OpenAI's (o1 and 4o) API and local Deepseek-R1 for Japan
                      financial auditing.
                    </li>
                    <li>Development of web scraping and data analytics infrastructure development.</li>
                    <li>
                      Integrated Assembly's API to transcribe audio to translate meetings to different languages and
                      summarize it.
                    </li>
                    <li>
                      Added application that allows clients to connect Google Drive and Confluence files to software.
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold">DEAN'S EARLY RESEARCH INITIATIVE PROGRAM (DERI)</h3>
                      <p className="text-muted-foreground">Machine Learning Intern</p>
                    </div>
                    <div className="text-right mt-2 md:mt-0">
                      <Badge variant="outline">May 2022 – May 2024</Badge>
                    </div>
                  </div>

                  <ul className="list-disc pl-5 space-y-2 mt-4">
                    <li>
                      Used machine learning to mitigate the mathematical equations in forecasting diseases like
                      Alzheimer, Diabetes, and Cancer.
                    </li>
                    <li>
                      Designed and implemented three machine learning algorithms (Random Forest, K-Nearest-Neighbor, and
                      Multi-layer Perceptron) using Python to model amyloid beta protein aggregation.
                    </li>
                    <li>
                      Utilized intelligent sampling to effectively process datasets to reduce the number of datasets
                      required.
                    </li>
                    <li>Presented at the 2023 DERI symposium and was awarded DEAN's scholarship.</li>
                    <li>1 pending research paper as one of the authors.</li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold">SUMMER RESEARCH OPPORTUNITY</h3>
                      <p className="text-muted-foreground">Machine Learning Intern</p>
                    </div>
                    <div className="text-right mt-2 md:mt-0">
                      <Badge variant="outline">June 2023 - September 2023</Badge>
                    </div>
                  </div>

                  <ul className="list-disc pl-5 space-y-2 mt-4">
                    <li>
                      Utilized DeepXDe to solve differential equations for complex protein aggregation kinetics,
                      mechanism, and curve-fitting.
                    </li>
                    <li>
                      Applied TensorFlow, PyTorch, and Matplotlib to machine learning software and loss value result
                      graphing.
                    </li>
                    <li>Implemented projects using Visual Studio Code, Google Collaboration, and PyCharm.</li>
                    <li>Completed 2 projects simultaneously with a lab of 8 (graduates, PhD students, and interns).</li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="business" className="space-y-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold">VIRGINIACOLIN</h3>
                      <p className="text-muted-foreground">CEO, Founder, and Head of Marketing</p>
                    </div>
                    <div className="text-right mt-2 md:mt-0">
                      <Badge variant="outline">Present</Badge>
                    </div>
                  </div>

                  <ul className="list-disc pl-5 space-y-2 mt-4">
                    <li>Sells online retail accounts for over 30 websites.</li>
                    <li>Over $200,000 in revenue with 150%-300% profit margins.</li>
                    <li>Over 30,000 customers from over 20 different countries.</li>
                    <li>One of the largest account suppliers in the Discord marketplace.</li>
                    <li>
                      Created a custom backend system that leverages Python for a more efficient account creation
                      system.
                    </li>
                    <li>
                      Partnered with 3 technology companies and 3 retail arbitrage groups to grow sales and network.
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold">JOLT INDUSTRY</h3>
                      <p className="text-muted-foreground">Software Developer and Technical Support</p>
                    </div>
                    <div className="text-right mt-2 md:mt-0">
                      <Badge variant="outline">March 2021 - August 2022</Badge>
                    </div>
                  </div>

                  <ul className="list-disc pl-5 space-y-2 mt-4">
                    <li>Assisted in the development of retail bots for over 2,000 subscribed members.</li>
                    <li>Collaborated with a team of 12 staff members to test and design unreleased updates.</li>
                    <li>
                      Supported over 600 customers with technical difficulty as online support as a part time service
                      agent.
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </SectionWrapper>

        {/* Contact Section */}
        <SectionWrapper id="contact" className="py-12">
          <div className="space-y-2 mb-8">
            <h2 className="text-3xl font-bold tracking-tight flex items-center gap-2">
              <Building className="h-6 w-6" /> Contact Me
            </h2>
            <p className="text-muted-foreground">Get in touch for opportunities or collaborations</p>
          </div>

          <Card className="overflow-hidden">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-center gap-8">
                <div className="space-y-4 flex-1">
                  <h3 className="text-xl font-bold mb-4">Contact Information</h3>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <Mail className="h-5 w-5 text-primary" />
                      <a href="mailto:colinzhang@berkeley.edu" className="hover:underline">
                        colinzhang@berkeley.edu
                      </a>
                    </div>
                    <div className="flex items-center gap-3">
                      <Linkedin className="h-5 w-5 text-primary" />
                      <a
                        href="https://www.linkedin.com/in/colin-zhang-b3988924a/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:underline"
                      >
                        LinkedIn Profile
                      </a>
                    </div>
                    <div className="flex items-center gap-3">
                      <Github className="h-5 w-5 text-primary" />
                      <a
                        href="https://github.com/ColinYZhang"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:underline"
                      >
                        GitHub Profile
                      </a>
                    </div>
                  </div>
                </div>
                <div className="flex-1 flex justify-center items-center">
                  <div className="text-center p-6 bg-primary/5 rounded-lg">
                    <h3 className="text-xl font-bold mb-4">Let's Connect!</h3>
                    <p className="mb-4">
                      I'm always open to discussing new projects, opportunities, or collaborations.
                    </p>
                    <div className="flex justify-center gap-4">
                      <Button asChild size="lg">
                        <a href="mailto:colinzhang@berkeley.edu" className="flex items-center">
                          <Mail className="mr-2 h-4 w-4" />
                          <span>Email Me</span>
                        </a>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </SectionWrapper>
      </main>

      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4 md:h-24">
          <p className="text-center md:text-left text-sm">
            © {new Date().getFullYear()} Colin Zhang. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <Link
              href="https://github.com/ColinYZhang"
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted-foreground hover:text-foreground"
            >
              <Github className="h-5 w-5" />
              <span className="sr-only">GitHub</span>
            </Link>
            <Link
              href="https://www.linkedin.com/in/colin-zhang-b3988924a/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted-foreground hover:text-foreground"
            >
              <Linkedin className="h-5 w-5" />
              <span className="sr-only">LinkedIn</span>
            </Link>
            <Link href="mailto:colinzhang@berkeley.edu" className="text-muted-foreground hover:text-foreground">
              <Mail className="h-5 w-5" />
              <span className="sr-only">Email</span>
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

